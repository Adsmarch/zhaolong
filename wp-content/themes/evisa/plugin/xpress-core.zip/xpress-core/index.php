<?php
//silence is golden